#import "../ActraPlugin.h"
#import <CoreFoundation/CoreFoundation.h>

@interface ActraSDKExampleProvider : NSObject <ActraActionProvider>
@property (nonatomic, getter=isEnabled) BOOL enabled;
@property (nonatomic, readonly) NSUInteger executionCount;
@property (nonatomic, readonly, copy) NSString *lastActionIdentifier;
@property (nonatomic, readonly, copy) NSDictionary *lastParameters;
@property (nonatomic, readonly, copy) NSDictionary *lastContext;
@property (nonatomic, readonly) ActraPluginResult lastResult;
+ (instancetype)sharedInstance;
- (BOOL)registerActions;
- (BOOL)unregisterActions;
@end

@implementation ActraSDKExampleProvider {
    NSUInteger _executionCount;
    NSString *_lastActionIdentifier;
    NSDictionary *_lastParameters;
    NSDictionary *_lastContext;
    ActraPluginResult _lastResult;
}
+ (instancetype)sharedInstance {
    static ActraSDKExampleProvider *provider;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ provider = [self new]; });
    return provider;
}
- (instancetype)init {
    if ((self = [super init])) _enabled = YES;
    return self;
}
- (NSDictionary<NSString *, id> *)providerDefinition {
    return @{@"sdkVersion":@1, @"id":@"com.mlgm.actra.sdkexample", @"title":@"SDK Example", @"actions":@[
        @{@"id":@"record", @"title":@"记录参数", @"description":@"记录收到的动作、参数和触发上下文。", @"symbolName":@"text.badge.checkmark", @"parameters":@[
            @{@"id":@"message", @"title":@"消息内容", @"kind":@"text", @"required":@YES, @"default":@"你好，Actra"},
            @{@"id":@"uppercase", @"title":@"英文字母转为大写", @"kind":@"toggle", @"default":@NO},
            @{@"id":@"level", @"title":@"级别", @"kind":@"slider", @"minimum":@0, @"maximum":@10, @"step":@1, @"default":@5},
            @{@"id":@"mode", @"title":@"模式", @"kind":@"choice", @"default":@"plain", @"options":@[
                @{@"value":@"plain", @"title":@"普通"}, @{@"value":@"emphasized", @"title":@"强调"}]}]},
        @{@"id":@"fail", @"title":@"返回失败", @"symbolName":@"exclamationmark.triangle"},
        @{@"id":@"cancel", @"title":@"返回取消", @"symbolName":@"xmark.circle"}
    ]};
}
- (BOOL)isActionAvailable:(NSString *)actionIdentifier {
    return self.enabled && [@[@"record", @"fail", @"cancel"] containsObject:actionIdentifier];
}
- (BOOL)canPerformAction:(NSString *)actionIdentifier parameters:(NSDictionary<NSString *,id> *)parameters context:(NSDictionary<NSString *,id> *)context {
    return [self isActionAvailable:actionIdentifier];
}
- (void)performAction:(NSString *)actionIdentifier parameters:(NSDictionary<NSString *,id> *)parameters context:(NSDictionary<NSString *,id> *)context completion:(ActraPluginCompletion)completion {
    if (![self isActionAvailable:actionIdentifier]) { completion(ActraPluginResultUnavailable, @"示例动作当前不可用"); return; }
    _executionCount++;
    _lastActionIdentifier = [actionIdentifier copy];
    _lastParameters = [parameters copy];
    _lastContext = [context copy];
    if ([actionIdentifier isEqualToString:@"fail"]) _lastResult = ActraPluginResultFailed;
    else if ([actionIdentifier isEqualToString:@"cancel"]) _lastResult = ActraPluginResultCancelled;
    else _lastResult = ActraPluginResultSuccess;
    NSString *message = parameters[@"message"];
    if ([parameters[@"uppercase"] boolValue]) message = message.uppercaseString;
    NSLog(@"[Actra SDK Example] %@ %@", actionIdentifier, message ?: @"");
    completion(_lastResult, _lastResult == ActraPluginResultFailed ? @"示例动作执行失败" : nil);
}
- (void)setEnabled:(BOOL)enabled {
    _enabled = enabled;
    Class managerClass = NSClassFromString(@"ActraPluginManager");
    NSError *error;
    if (![(ActraPluginManager *)[managerClass sharedManager] providerAvailabilityDidChange:self error:&error] && error)
        NSLog(@"[Actra SDK Example] %@", error.localizedDescription);
}
- (BOOL)registerActions {
    Class managerClass = NSClassFromString(@"ActraPluginManager");
    NSError *error;
    BOOL registered = [(ActraPluginManager *)[managerClass sharedManager] registerProvider:self error:&error];
    if (error) NSLog(@"[Actra SDK Example] %@", error.localizedDescription);
    return registered;
}
- (BOOL)unregisterActions {
    Class managerClass = NSClassFromString(@"ActraPluginManager");
    NSError *error;
    BOOL result = [(ActraPluginManager *)[managerClass sharedManager] unregisterProvider:self error:&error];
    if (error) NSLog(@"[Actra SDK Example] %@", error.localizedDescription);
    return result;
}
@end

static void ExampleReady(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{ [ActraSDKExampleProvider.sharedInstance registerActions]; });
}

__attribute__((constructor)) static void InitializeExample(void) {
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, ExampleReady, (__bridge CFStringRef)ActraPluginsReadyNotification, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    dispatch_async(dispatch_get_main_queue(), ^{ [ActraSDKExampleProvider.sharedInstance registerActions]; });
}
