#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define ActraPluginsReadyNotification @"com.mlgm.actra.plugins.ready"
#define ActraPluginErrorDomain @"com.mlgm.actra.plugins"
#define ActraPluginErrorFieldPathKey @"fieldPath"

typedef NS_ENUM(NSInteger, ActraPluginErrorCode) {
    ActraPluginErrorInvalidDefinition = 1,
    ActraPluginErrorConflict,
    ActraPluginErrorNotRegistered,
    ActraPluginErrorBusy,
    ActraPluginErrorWrongThread,
    ActraPluginErrorPersistence,
    ActraPluginErrorProviderException,
};

typedef NS_ENUM(NSInteger, ActraPluginResult) {
    ActraPluginResultSuccess = 0,
    ActraPluginResultFailed,
    ActraPluginResultUnavailable,
    ActraPluginResultCancelled,
};

typedef void (^ActraPluginCompletion)(ActraPluginResult result, NSString * _Nullable message);

@protocol ActraActionProvider <NSObject>
- (NSDictionary<NSString *, id> *)providerDefinition;
- (void)performAction:(NSString *)actionIdentifier
           parameters:(NSDictionary<NSString *, id> *)parameters
              context:(NSDictionary<NSString *, id> *)context
           completion:(ActraPluginCompletion)completion;
@optional
- (BOOL)isActionAvailable:(NSString *)actionIdentifier;
- (BOOL)canPerformAction:(NSString *)actionIdentifier
              parameters:(NSDictionary<NSString *, id> *)parameters
                 context:(NSDictionary<NSString *, id> *)context;
- (void)cancelAction:(NSString *)actionIdentifier context:(NSDictionary<NSString *, id> *)context;
@end

@interface ActraPluginManager : NSObject
+ (nullable instancetype)sharedManager;
- (BOOL)registerProvider:(id<ActraActionProvider>)provider error:(NSError * _Nullable * _Nullable)error;
- (BOOL)unregisterProvider:(id<ActraActionProvider>)provider error:(NSError * _Nullable * _Nullable)error;
- (BOOL)providerAvailabilityDidChange:(id<ActraActionProvider>)provider error:(NSError * _Nullable * _Nullable)error;
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
@end

NS_ASSUME_NONNULL_END
