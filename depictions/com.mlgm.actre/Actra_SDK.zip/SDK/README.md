# Actra 插件动作 SDK

第三方插件通过 [ActraPlugin.h](ActraPlugin.h) 注册动作。用户在「Actra → 动作 → 选择功能 → 插件功能」中选择动作、配置参数，再绑定手势、按键或事件触发器。

## 接入步骤

1. 使用 iOS 15 或更新系统，将插件注入 `com.apple.springboard`。
2. 复制并导入 `ActraPlugin.h`，链接 Foundation、CoreFoundation，按设备环境构建 RootHide 或 rootless 包。
3. 实现 `ActraActionProvider`，提供动作定义和执行回调。
4. 监听 `ActraPluginsReadyNotification`，并在主队列尝试注册，具体代码见下文。

独立动作插件的包依赖添加 `com.mlgm.actra`。已有插件也可将 Actra 作为可选集成，未安装时跳过注册。通过 `NSClassFromString(@"ActraPluginManager")` 获取管理器，无需链接 Actra.dylib，不要直接引用管理器的类符号。

所有管理器方法、提供者回调和完成回调都在主线程执行。管理器强引用已注册的提供者；耗时任务请放到后台队列。

## 动作提供者

| 方法 | 必需 | 说明 |
| --- | --- | --- |
| `providerDefinition` | 是 | 返回插件、动作和参数定义。 |
| `performAction:parameters:context:completion:` | 是 | 执行动作，完成后调用一次 `completion`。 |
| `isActionAvailable:` | 否 | 动作当前是否可用；省略时默认可用，适合反映插件总开关或服务状态。 |
| `canPerformAction:parameters:context:` | 否 | 本次触发能否执行，适合检查锁屏、当前界面等条件；只做判断，不执行实际业务。 |
| `cancelAction:context:` | 否 | 超时后收到取消请求，按 `invocationIdentifier` 停止对应异步任务。 |

### 插件与动作定义

`providerDefinition` 返回只含下列字段的字典，所有值须符合 property list 数据类型。名称、说明、参数标题和选项标题由插件返回最终显示文本。

| 插件字段 | 说明 |
| --- | --- |
| `sdkVersion` | 固定为数字 `@1`，表示接口格式。 |
| `id` | 稳定、唯一的反向域名标识，例如 `com.example.myplugin`。 |
| `title` | 插件显示名称，非空，最多 1024 字符。 |
| `actions` | 动作数组，包含 1–64 个动作。 |

```objc
- (NSDictionary *)providerDefinition {
    return @{
        @"sdkVersion": @1,
        @"id": @"com.example.myplugin",
        @"title": @"My Plugin",
        @"actions": @[@{
            @"id": @"record",
            @"title": @"记录消息",
            @"symbolName": @"text.bubble",
            @"parameters": @[@{
                @"id": @"message", @"title": @"消息内容", @"kind": @"text",
                @"required": @YES, @"default": @"你好，Actra"
            }]
        }]
    };
}
```

| 动作字段 | 说明 |
| --- | --- |
| `id` | 必填，插件内唯一且稳定；执行回调收到的 `actionIdentifier` 就是此值。 |
| `title` | 必填，非空显示名称，最多 1024 字符。 |
| `description` | 可选，非空动作说明，最多 1024 字符。 |
| `symbolName` | SF Symbols 名称，最多 128 字符；与 `iconPNG` 至少提供一个。 |
| `iconPNG` | 可选 `NSData`，单帧 PNG，最多 256 KiB，宽高分别不超过 512 像素；同时提供时优先使用 PNG。 |
| `template` | 可选布尔值，默认 `YES`，图标随界面着色；彩色 PNG 设为 `NO`。 |
| `parameters` | 可选参数数组，最多 64 项；省略表示无参数。 |
| `executionTimeout` | 可选有限数字，1–300 秒，默认 30 秒。 |

插件、动作和参数标识只允许英文字母、数字、点、下划线和连字符，点分段不能为空，每个标识最多 128 字符。插件标识必须含点；组合后的 `plugin:<插件标识>:<动作标识>` 也不能超过 128 字符。动作和参数标识分别在所属插件、动作内唯一，发布后保持稳定。

最多同时注册 64 个提供者，单个提供者定义最多 4 MiB。仅使用本文列出的字段。图标使用透明背景，Actra 会去除外围透明留白并等比居中，无需为不同页面分别提供图标。

### 参数定义

每项参数必填 `id`、`title`、`kind`。Actra 根据定义生成参数界面，并将用户值与默认值合并后传给预检和执行回调。

| `kind` | 值与约定 |
| --- | --- |
| `text` | 字符串，文本输入。 |
| `toggle` | 布尔值，开关；未提供默认值时为 `NO`。 |
| `number` | 有限数字；未配置且无默认值时省略，不会自动传入零。 |
| `slider` | 有限数字，滑块；必须提供 `minimum`、`maximum`，默认值省略时使用下限。 |
| `choice` | 单选；选项值为非空字符串或有限数字，同组选项类型一致，不接受布尔值。 |
| `multiChoice` | 多选；值为非空字符串组成的数组。 |
| `application` | 应用单选；值为 bundle ID 字符串。 |
| `applications` | 应用多选；值为 bundle ID 数组。 |

- 通用可选字段：`subtitle`、`required`、`default`。`required` 默认 `NO`；必填字符串和数组不能为空。缺少必填值时不执行动作，可选值未配置且无默认值时省略。
- `title`、`subtitle`、`unit` 最多 1024 字符，提供时须非空。字符串参数值最多 4096 字符，数组最多 256 个非空、不重复的字符串。
- 仅 `number`、`slider` 可提供 `minimum`、`maximum`、`step`、`unit`。数值须有限，下限不能大于上限，步长须大于零；提供步长时，上限、默认值和实际值须以 `minimum`（省略时为零）为起点对齐步长。
- `choice`、`multiChoice` 必须提供 `options`，其他类型不接受此字段。每项只包含 `value`、`title`；最多 256 项，值不得重复，默认值必须属于选项。
- 默认值须符合参数类型和约束。可选文本、应用单选被清空时传入空字符串，多选被清空时传入空数组；这些显式空值会覆盖默认值。

## 注册与状态变更

`sharedManager` 在非主线程或 Actra 尚未就绪时返回 `nil`。构造函数先监听 Darwin ready 通知，再向主队列提交一次注册，避免依赖 dylib 加载顺序。通知可能重复发送，应始终使用同一提供者对象注册。

下面假设 `MyProvider.sharedInstance` 是已实现 `ActraActionProvider` 的单例；完整代码见[示例源码](Example/ActraSDKExampleProvider.m)。

```objc
static void RegisterActions(void) {
    Class managerClass = NSClassFromString(@"ActraPluginManager");
    ActraPluginManager *manager = [managerClass sharedManager];
    if (!manager) return;
    NSError *error = nil;
    if (![manager registerProvider:MyProvider.sharedInstance error:&error]) {
        NSLog(@"注册动作失败：%@", error.localizedDescription);
    }
}

static void PluginsReady(CFNotificationCenterRef center, void *observer,
                         CFStringRef name, const void *object,
                         CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterActions(); });
}

__attribute__((constructor)) static void InitializeProvider(void) {
    if (![NSBundle.mainBundle.bundleIdentifier isEqualToString:@"com.apple.springboard"]) return;
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), NULL, PluginsReady,
        (__bridge CFStringRef)ActraPluginsReadyNotification, NULL,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterActions(); });
}
```

| 管理器方法 | 说明 |
| --- | --- |
| `registerProvider:error:` | 注册或更新同一对象的定义；失败时保留原注册。不同对象不能占用同一插件标识，已注册对象不能更换标识。 |
| `providerAvailabilityDidChange:error:` | 插件开关或服务状态变化后调用，重新查询 `isActionAvailable:` 并更新显示状态。 |
| `unregisterProvider:error:` | 注销原注册对象；只有返回 `YES` 才表示成功。 |

上述方法返回 `BOOL`，失败时检查 `NSError`。错误域为 `ActraPluginErrorDomain`，错误码见头文件的 `ActraPluginErrorCode`。定义校验失败时，`error.userInfo[ActraPluginErrorFieldPathKey]` 指出字段位置，例如 `actions[0].parameters[2]`。

不要在定义、可用性等同步查询回调中重入注册或注销。忙碌时会返回 `ActraPluginErrorBusy`；配置切换结束会再次发送 ready，可在收到通知后重试。状态发布失败不会撤销插件自身的开关变化，执行时仍会查询当前可用性。

成功注销后不再接受新调用，已经进入执行的业务仍需完成回调。卸载并重启 SpringBoard 后，未注册动作显示为不可用；用户已保存的动作标识和参数保留，重新注册相同标识后可继续使用。

## 执行回调

`performAction:parameters:context:completion:` 中的 `parameters` 已通过校验并应用默认值。执行结束时，在主线程调用一次 `completion(result, message)`；`message` 可为 `nil`，或返回用户可理解的说明。

| 结果 | 含义 |
| --- | --- |
| `ActraPluginResultSuccess` | 动作成功；打开界面类动作可在界面成功启动后完成，异步业务也可在任务结束后完成。 |
| `ActraPluginResultFailed` | 执行失败。 |
| `ActraPluginResultUnavailable` | 当前不可用或无法执行。 |
| `ActraPluginResultCancelled` | 本次执行取消。 |

| `context` 字段 | 类型与用途 |
| --- | --- |
| `invocationIdentifier` | 本次调用的唯一字符串标识，正式执行与取消回调一致；预检不包含此字段。 |
| `triggerIdentifier`、`eventIdentifier`、`sourceIdentifier` | 字符串，描述触发来源，供诊断使用。 |
| `timestamp` | `NSDate`，触发事件时间。 |
| `metadata` | 诊断字典，具体字段随触发器变化，不作为插件业务参数。 |

耗时任务应在后台执行，结束后回到主线程调用完成回调。超过 `executionTimeout` 时，Actra 向实现了 `cancelAction:context:` 的提供者发送取消请求；请用 `invocationIdentifier` 定位任务。取消不会自动撤销已产生的效果，正常完成不会调用取消方法。重复回调和超时后的回调不会再次推进动作，主线程阻塞也无法被超时计时器强制中断。

## 示例与构建

[Example/ActraSDKExampleProvider.m](Example/ActraSDKExampleProvider.m) 提供 `SDK Example` 分组，界面文案使用中文：

- 「记录参数」：演示文本、开关、滑块、单选参数，并记录动作、参数和触发上下文。
- 「返回失败」「返回取消」：演示不同完成结果。

示例的 `registerActions`、`unregisterActions` 和 `setEnabled:` 展示注册、注销与可用性更新；`executionCount`、`lastActionIdentifier`、`lastParameters`、`lastContext`、`lastResult` 可用于检查执行结果。

在本 SDK 的 `Example` 目录执行，`THEOS` 替换为本机 Theos 路径：

```sh
THEOS=/opt/theos make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide
THEOS=/opt/theos make clean package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
```

两种方案按顺序构建，安装与设备环境对应的示例包并重启 SpringBoard。在「插件功能 → SDK Example」选择动作、配置参数并绑定触发器后测试。用于自己的插件时，更换包标识 `com.mlgm.actra.sdkexample`、提供者标识及类名，并实现实际业务。
