#import "../ClippaPlugin.h"

@interface ClippaExamplePlugin : NSObject <ClippaPlugin>
+ (instancetype)sharedInstance;
@end
@implementation ClippaExamplePlugin
+ (instancetype)sharedInstance {
    static ClippaExamplePlugin *plugin;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ plugin = [self new]; });
    return plugin;
}
- (NSString *)pluginIdentifier { return @"com.example.clippa.copy"; }
- (NSString *)displayName { return @"复制选区图片"; }
- (UIImage *)icon { return [UIImage systemImageNamed:@"doc.on.doc"]; }
- (NSString *)pluginDescription { return @"将选区图片复制到剪贴板。"; }
- (BOOL)enabledInitially { return NO; }
- (void)processImage:(UIImage *)image { UIPasteboard.generalPasteboard.image = image; }
@end

static void RegisterPlugin(void) {
    Class managerClass = NSClassFromString(@"ClippaPluginManager");
    ClippaPluginManager *manager = [managerClass sharedManager];
    if (!manager) return;
    NSError *error;
    if (![manager registerPlugin:ClippaExamplePlugin.sharedInstance error:&error]) NSLog(@"[Clippa Example] %@", error.localizedDescription);
}
static void PluginsReady(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterPlugin(); });
}
__attribute__((constructor)) static void InitializePlugin(void) {
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL, PluginsReady, (__bridge CFStringRef)ClippaPluginsReadyNotification, NULL, CFNotificationSuspensionBehaviorDeliverImmediately);
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterPlugin(); });
}
