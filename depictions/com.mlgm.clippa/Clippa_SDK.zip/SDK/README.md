# Clippa SDK

外部调用方向 Clippa 传入图片并悬浮，使用 [ClippaPinning.h](ClippaPinning.h)，详见[外部图片悬浮接入](Pinning.md)。图片准备与业务界面由调用方实现；Clippa 只接收图片并管理贴图，历史行为跟随现有设置。此接口不注册菜单插件，也不在工具栏或插件管理页添加调用方条目。

第三方插件通过 [ClippaPlugin.h](ClippaPlugin.h) 在选区下方工具栏添加按钮，点击后接收选区图片。用户在「Clippa → 基础操作」中启用、禁用和排序。

## 选区菜单插件接入步骤

1. 使用 iOS 15 或更新系统，将插件注入 `com.apple.springboard`。
2. 复制并导入 `ClippaPlugin.h`，链接 UIKit，在包依赖中添加 `com.mlgm.clippa`。
3. 实现 `ClippaPlugin`，提供标识、名称、图标和图片回调。
4. 监听 `ClippaPluginsReadyNotification`，并在主队列尝试注册，具体代码见下文。

按设备环境构建 RootHide 或 rootless 包。通过 `NSClassFromString(@"ClippaPluginManager")` 获取管理器，无需链接 Clippa.dylib，不要直接引用管理器的类符号。所有公共方法和插件回调都在主线程执行，管理器强引用已注册对象。

## 插件接口

| 方法                  | 必需 | 说明                                                                                     |
| ------------------- | -- | -------------------------------------------------------------------------------------- |
| `pluginIdentifier`  | 是  | 稳定、唯一的反向域名标识，例如 `com.example.clippa.copy`。最多 128 字符，只允许英文字母、数字、点、下划线和连字符；必须含点，点分段不能为空。 |
| `displayName`       | 是  | 按钮无障碍名称及设置中的名称，不能只含空白，最多 1024 字符。                                                      |
| `icon`              | 是  | 包含可见内容的 `UIImage`，宽高分别不超过 512 像素，支持 SF Symbols。使用透明背景，宿主按可见内容等比居中并统一单色着色。              |
| `processImage:`     | 是  | 用户点击已启用的按钮后，接收裁剪后的选区 `UIImage`。                                                        |
| `pluginDescription` | 否  | 设置中的说明，最多 1024 字符；省略或返回 `nil` 表示无说明。                                                   |
| `enabledInitially`  | 否  | 首次默认是否启用，省略时为 `YES`；用户保存的设置优先。                                                         |
| `isAvailable`       | 否  | 当前是否可用，省略时为 `YES`；适合反映插件总开关或服务状态。                                                      |

名称和说明由插件返回最终显示文本。最多注册 64 个菜单插件。名称、图标、说明和默认启用状态在注册时读取，发生变化后对同一对象重新调用 `registerPlugin:error:` 更新。

## 注册与状态变更

`sharedManager` 在非主线程或 Clippa 尚未就绪时返回 `nil`。构造函数先监听 Darwin ready 通知，再向主队列提交一次注册，避免依赖 dylib 加载顺序。重复注册使用同一插件对象。

下面假设 `MyPlugin.sharedInstance` 是已实现 `ClippaPlugin` 的单例；完整代码见[示例源码](Example/ClippaExamplePlugin.m)。

```objc
static void RegisterPlugin(void) {
    Class managerClass = NSClassFromString(@"ClippaPluginManager");
    ClippaPluginManager *manager = [managerClass sharedManager];
    if (!manager) return;
    NSError *error = nil;
    if (![manager registerPlugin:MyPlugin.sharedInstance error:&error]) {
        NSLog(@"注册菜单插件失败：%@", error.localizedDescription);
    }
}

static void PluginsReady(CFNotificationCenterRef center, void *observer,
                         CFStringRef name, const void *object,
                         CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterPlugin(); });
}

__attribute__((constructor)) static void InitializePlugin(void) {
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), NULL, PluginsReady,
        (__bridge CFStringRef)ClippaPluginsReadyNotification, NULL,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    dispatch_async(dispatch_get_main_queue(), ^{ RegisterPlugin(); });
}
```

| 管理器接口                                | 说明                                                       |
| ------------------------------------ | -------------------------------------------------------- |
| `registerPlugin:error:`              | 注册或更新同一对象；不同对象不能占用同一标识，已注册对象不能更换标识。内容未变时重复注册不产生更新。       |
| `pluginAvailabilityDidChange:error:` | 插件开关或服务状态变化后调用，重新查询 `isAvailable`。不可用时按钮隐藏，用户的启用状态与排序保留。 |
| `unregisterPlugin:error:`            | 注销原注册对象；只有返回 `YES` 才表示成功。                                |
| `registeredPluginIdentifiers`        | 只读数组，按标识排序，包含当前已注册插件的标识。                                 |

三个变更方法均返回 `BOOL`，失败时检查 `NSError`，原注册状态保留。错误域为 `ClippaPluginErrorDomain`，错误码见头文件的 `ClippaPluginErrorCode`。先确认管理器非 `nil`，不要把向 `nil` 发送消息得到的 `NO` 当成注册错误。

不要在名称、图标、可用性等同步查询回调中重入修改注册表，否则返回 `ClippaPluginErrorBusy`。用户的启用状态和排序由 Clippa 管理，插件通过上述接口发布自身状态即可。

## 图片回调

- `processImage:` 在主线程接收一次选区图片，保留截图像素和 `scale`，方向为 `UIImageOrientationUp`。标准模式使用实际采集画面，冻结模式使用冻结画面。
- 图片交付前关闭选区界面，图片不包含 Clippa 工具栏。是否复制、保存或上传由插件自行实现。
- 尚未交付的图片可能因取消、旋转、切换前台应用、禁用、注销或注册内容变化而丢弃，不应假定每次点击都必然回调。
- 耗时处理放到后台队列；异步使用时持有图片。接口只交付图片，不接收业务完成回调。
- 注销后不再交付旧操作，已进入回调的业务由插件自行收尾。卸载并重启 SpringBoard 后插件移出当前菜单；重新注册相同标识可恢复用户保存的启用状态和排序。

## 示例与构建

[Example/ClippaExamplePlugin.m](Example/ClippaExamplePlugin.m) 提供「复制选区图片」按钮，默认关闭，点击后将图片复制到剪贴板。示例的显示名称和说明均使用中文，包名保留 `Clippa Example Plugin`。

在本 SDK 的 `Example` 目录执行，`THEOS` 替换为本机 Theos 路径：

```sh
THEOS=/opt/theos make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=roothide
THEOS=/opt/theos make clean package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
```

两种方案按顺序构建，安装与设备环境对应的示例包并重启 SpringBoard。在「Clippa → 基础操作」中启用「复制选区图片」，选择区域并点击该按钮，再粘贴到支持图片的应用确认结果。

用于自己的插件时，更换包标识和插件标识 `com.example.clippa.copy`、类名，并实现 `processImage:` 中的业务。
