# 外部图片悬浮

使用 `ClippaPinning.h`，在 SpringBoard 主线程调用。只链接 UIKit，通过 `NSClassFromString(@"ClippaPinningController")` 找到公开类，不链接 Clippa.dylib。

```objc
#import "ClippaPinning.h"

Class controller = NSClassFromString(@"ClippaPinningController");
if (!controller ||
    ![controller respondsToSelector:@selector(isAvailable)] ||
    ![controller respondsToSelector:@selector(pinImage:initialFrame:error:)]) return;
NSError *error = nil;
BOOL displayed = [controller pinImage:image initialFrame:CGRectZero error:&error];
if (!displayed) NSLog(@"悬浮失败：%@", error);
```

`image` 是调用方准备的静态 UIImage，必须有 CGImage。文字先渲染为图片。最长边最多 4096 像素，总量最多 16,000,000 像素；透明内容和图片方向正常保留，超限先等比缩小。

`CGRectZero` 自动布局；其他矩形使用当前方向下的屏幕 points，Clippa 等比布局并修正到可见安全区域。调用方不访问 Clippa 窗口或视图。

`isAvailable` 是无副作用的预检查，点击时仍须检查创建结果。`YES` 表示图片已经进入可显示浮层并完成所需存储，调用方可释放输入图片。`NO` 不留下本次贴图，若错误指针非空则返回错误域 `ClippaPinningErrorDomain` 的 NSError；错误码见头文件。未安装 Clippa 或未提供本接口时由调用方处理，不能将向 nil 发消息得到的 NO 当成宿主错误。

**是否进入历史完全跟随 Clippa 现有历史设置**：数量为 0 时只悬浮，大于 0 时保存并按上限整理，负数不限。Clippa 原有选区编辑、带壳等功能继续沿用现有设置；贴图菜单目前没有编辑或带壳入口，本接口不新增这些菜单项。创建本身不复制到剪贴板、不保存到相册、不上传。

锁定、关闭总开关或正在选区、长截图、全屏翻译、图片编辑等冲突操作时立即失败，不取消原任务、不等待解锁、不自动重试。历史写入失败返回 `Persistence`，底层错误可从 `NSUnderlyingErrorKey` 取得。

贴图使用 Clippa 原有交互与外观。原图用于复制、保存、分享及图像处理；显示缩略图不会降低这些操作的输入清晰度。历史数量为 0 时分享文件按需创建并随消费者结束清理；开启历史时文件由现有历史管理。

本接口与选区菜单插件接口互相独立，不需要实现 `ClippaPlugin` 或注册插件，也不在 Clippa 工具栏或插件管理页添加条目。调用方的内容来源、文字排版、按钮及错误提示均由调用方实现，不属于 SDK。RootHide 和 rootless 使用相同头文件，设备实测范围另行记录。
