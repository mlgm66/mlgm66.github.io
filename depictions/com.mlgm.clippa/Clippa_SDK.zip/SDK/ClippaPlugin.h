#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
#define ClippaPluginsReadyNotification @"com.mlgm.clippa.plugins.ready"
#define ClippaPluginErrorDomain @"com.mlgm.clippa.plugins"
typedef NS_ENUM(NSInteger, ClippaPluginErrorCode) {
    ClippaPluginErrorWrongThread = 1,
    ClippaPluginErrorInvalidPlugin,
    ClippaPluginErrorInvalidMetadata,
    ClippaPluginErrorIdentifierConflict,
    ClippaPluginErrorNotRegistered,
    ClippaPluginErrorPersistence,
    ClippaPluginErrorBusy,
    ClippaPluginErrorProviderException,
    ClippaPluginErrorLimitExceeded,
};
@protocol ClippaPlugin <NSObject>
- (NSString *)pluginIdentifier;
- (NSString *)displayName;
- (UIImage *)icon;
- (void)processImage:(UIImage *)image;
@optional
- (nullable NSString *)pluginDescription;
- (BOOL)enabledInitially;
- (BOOL)isAvailable;
@end
@interface ClippaPluginManager : NSObject
+ (nullable instancetype)sharedManager;
@property (nonatomic, readonly, copy) NSArray<NSString *> *registeredPluginIdentifiers;
- (BOOL)registerPlugin:(id<ClippaPlugin>)plugin error:(NSError * _Nullable * _Nullable)error;
- (BOOL)unregisterPlugin:(id<ClippaPlugin>)plugin error:(NSError * _Nullable * _Nullable)error;
- (BOOL)pluginAvailabilityDidChange:(id<ClippaPlugin>)plugin error:(NSError * _Nullable * _Nullable)error;
- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;
@end
NS_ASSUME_NONNULL_END
